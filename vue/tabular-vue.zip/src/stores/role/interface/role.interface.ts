export interface Role {
    id: number;
    role: string;
}